import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_image_labeling/google_mlkit_image_labeling.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:vibration/vibration.dart';

void main() => runApp(const HassasApp());

class HassasApp extends StatelessWidget {
  const HassasApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HASSAS AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1769AA)),
        scaffoldBackgroundColor: const Color(0xFFF5F8FC),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final ImagePicker _picker = ImagePicker();
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();

  late final ImageLabeler _labeler = ImageLabeler(
    options: ImageLabelerOptions(confidenceThreshold: 0.50),
  );
  late final TextRecognizer _latinRecognizer =
      TextRecognizer(script: TextRecognitionScript.latin);

  String _result = 'أهلاً بك في حسّاس AI. اختر إحدى وسائل المساعدة.';
  bool _busy = false;
  bool _listening = false;
  String _heardWords = '';

  @override
  void initState() {
    super.initState();
    _configureTts();
  }

  Future<void> _configureTts() async {
    await _tts.setLanguage('ar');
    await _tts.setSpeechRate(0.45);
    await _tts.setVolume(1.0);
  }

  Future<void> _speak(String text) async {
    await _tts.stop();
    await _tts.speak(text);
  }

  Future<void> _smartEye() async {
    final XFile? photo = await _picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 85,
    );
    if (photo == null || !mounted) return;

    setState(() {
      _busy = true;
      _result = 'جاري تحليل الصورة...';
    });

    try {
      final input = InputImage.fromFilePath(photo.path);
      final labels = await _labeler.processImage(input);
      final recognized = await _latinRecognizer.processImage(input);

      final labelText = labels.isEmpty
          ? 'لم أتعرف على عناصر واضحة في الصورة.'
          : labels.take(5).map((e) =>
              '${e.label} — ${(e.confidence * 100).round()}%').join('\n');

      final buffer = StringBuffer('نتيجة التعرف على الأشياء:\n$labelText');
      if (recognized.text.trim().isNotEmpty) {
        buffer.write('\n\nالنص المكتشف (يدعم حالياً الحروف اللاتينية):\n');
        buffer.write(recognized.text);
      } else {
        buffer.write('\n\nلم يتم اكتشاف نص لاتيني واضح.');
      }

      if (!mounted) return;
      setState(() => _result = buffer.toString());
      await _speak('تم تحليل الصورة. $labelText');
    } catch (e) {
      if (mounted) {
        setState(() => _result =
            'تعذر تحليل الصورة. تأكد من أذونات الكاميرا وحاول مرة أخرى.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _toggleListening() async {
    if (_listening) {
      await _speech.stop();
      if (mounted) setState(() => _listening = false);
      return;
    }

    final available = await _speech.initialize(
      onStatus: (status) {
        if (status == 'done' || status == 'notListening') {
          if (mounted) setState(() => _listening = false);
        }
      },
      onError: (error) {
        if (mounted) {
          setState(() {
            _listening = false;
            _result = 'تعذر التعرف على الكلام: تحقق من إذن الميكروفون وإعدادات اللغة.';
          });
        }
      },
    );

    if (!available) {
      setState(() => _result =
          'خدمة التعرف على الكلام غير متاحة على هذا الهاتف.');
      return;
    }

    setState(() {
      _listening = true;
      _heardWords = '';
      _result = 'جاري الاستماع...';
    });

    await _speech.listen(
      localeId: 'ar',
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 4),
      onResult: (value) {
        if (!mounted) return;
        setState(() {
          _heardWords = value.recognizedWords;
          _result = _heardWords.isEmpty ? 'جاري الاستماع...' : _heardWords;
        });
      },
    );
  }

  Future<void> _communicate(String message) async {
    setState(() => _result = message);
    await _speak(message);
    try {
      final hasVibrator = await Vibration.hasVibrator();
      if (hasVibrator == true) {
        await Vibration.vibrate(duration: 180);
      }
    } catch (_) {
      // Vibration is optional; speech remains available.
    }
  }

  Widget _featureCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 0,
      color: color.withOpacity(0.10),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: _busy ? null : onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 38),
              const SizedBox(height: 10),
              Text(title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.bold)),
              const SizedBox(height: 5),
              Text(subtitle,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12, color: Colors.black54)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _phraseButton(String title, String phrase) {
    return OutlinedButton.icon(
      onPressed: () => _communicate(phrase),
      icon: const Icon(Icons.volume_up),
      label: Text(title),
      style: OutlinedButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
      ),
    );
  }

  @override
  void dispose() {
    _labeler.close();
    _latinRecognizer.close();
    _speech.stop();
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('HASSAS AI | حسّاس',
              style: TextStyle(fontWeight: FontWeight.bold)),
          centerTitle: true,
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF1769AA), Color(0xFF43A5D8)],
                ),
                borderRadius: BorderRadius.circular(22),
              ),
              child: const Column(
                children: [
                  Icon(Icons.accessibility_new, color: Colors.white, size: 44),
                  SizedBox(height: 8),
                  Text('تكنولوجيا تفهم احتياجاتك',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 21,
                          fontWeight: FontWeight.bold)),
                  SizedBox(height: 5),
                  Text('مساعد تجريبي للتواصل والوصول للمعلومات',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white)),
                ],
              ),
            ),
            const SizedBox(height: 18),
            if (_busy) const LinearProgressIndicator(),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 1.12,
              children: [
                _featureCard(
                  title: 'العين الذكية',
                  subtitle: 'التعرف على الأشياء والتقاط النصوص',
                  icon: Icons.visibility,
                  color: Colors.blue,
                  onTap: _smartEye,
                ),
                _featureCard(
                  title: _listening ? 'إيقاف الاستماع' : 'الأذن الذكية',
                  subtitle: 'تحويل الكلام إلى كتابة',
                  icon: Icons.hearing,
                  color: Colors.green,
                  onTap: _toggleListening,
                ),
              ],
            ),
            const SizedBox(height: 18),
            const Text('عبّر عن نفسك',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _phraseButton('💧 أريد الماء', 'أريد شرب الماء من فضلك.'),
                _phraseButton('🆘 أحتاج مساعدة', 'أحتاج إلى المساعدة من فضلك.'),
                _phraseButton('🍽️ أريد الطعام', 'أريد تناول الطعام من فضلك.'),
                _phraseButton('نعم', 'نعم.'),
                _phraseButton('لا', 'لا.'),
                _phraseButton('شكراً', 'شكراً جزيلاً.'),
              ],
            ),
            const SizedBox(height: 18),
            Card(
              elevation: 0,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('النتيجة',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    SelectableText(_result,
                        style: const TextStyle(fontSize: 16, height: 1.5)),
                    const SizedBox(height: 8),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: TextButton.icon(
                        onPressed: () => _speak(_result),
                        icon: const Icon(Icons.volume_up),
                        label: const Text('اقرأ النتيجة'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'نسخة تجريبية للمسابقة — لا تستخدم للتنقل الآمن أو للطوارئ.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11, color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}
